import React, { useEffect, useState } from "react";
import { 
  Activity, 
  Box, 
  LayoutDashboard, 
  Settings, 
  Wallet,
  Zap,
  QrCode,
  Mail,
  Smartphone,
  Lock,
  ArrowRight,
  MonitorSmartphone,
  ShieldCheck,
  Coins,
  Building2,
  Image as ImageIcon,
  LineChart as LineChartIcon,
  TrendingUp,
  Users,
  Rocket,
  Pickaxe,
  Shield,
  LogOut
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from "recharts";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import { auth, db } from "./firebase";
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, OAuthProvider } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { SettingsPanel } from "./components/SettingsPanel";
import { SubscriptionPlans } from "./components/SubscriptionPlans";
import { AssetIssuance, RWAInfrastructure, NFTMarketplace } from "./components/AssetModules";
import { TradingEngine, Derivatives, CopyTrading, Launchpad } from "./components/TradingModules";
import { MiningPools, CustodyStorage } from "./components/InfrastructureModules";
import { SubscriptionPlans } from "./components/SubscriptionPlans";

interface KaleidoData {
  nodeState: string;
  chaosLevel: string;
  damping: string;
  syncStatus: string;
  recentBlocks: Array<{
    id: string;
    timestamp: string;
    transactions: number;
    status: string;
  }>;
  chartData: Array<{
    time: string;
    stability: number;
    chaos: number;
  }>;
}

interface WhiteLabelConfig {
  appName: string;
  primaryColor: string;
  logoUrl?: string;
  tokenName?: string;
  kaleidoRestUrl?: string;
  kaleidoAuthHeader?: string;
}

export default function App() {
  const [data, setData] = useState<KaleidoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [config, setConfig] = useState<WhiteLabelConfig | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [showSubscriptions, setShowSubscriptions] = useState(false);
  const [subscriptionTier, setSubscriptionTier] = useState<string | null>(null);

  useEffect(() => {
    const fetchConfig = async (uid: string) => {
      const docRef = doc(db, "whiteLabelConfigs", uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setConfig(docSnap.data() as WhiteLabelConfig);
      } else {
        setConfig({
          appName: "Axiom Trading Platform",
          primaryColor: "#3b82f6"
        });
      }
    };

    // Check for referral ID in URL
    const urlParams = new URLSearchParams(window.location.search);
    const refId = urlParams.get('ref');

    if (refId) {
      // If referred, load the referrer's config
      fetchConfig(refId);
    }

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // If no referral ID, load the user's own config
        if (!refId) {
          fetchConfig(currentUser.uid);
        }
        
        // Check subscription status (mock for now)
        const subRef = doc(db, "subscriptions", currentUser.uid);
        const subSnap = await getDoc(subRef);
        if (subSnap.exists()) {
          setSubscriptionTier(subSnap.data().tier);
        } else {
          // If no subscription, show plans
          setShowSubscriptions(true);
        }
      } else {
        if (!refId) {
          setConfig(null);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      try {
        const headers: Record<string, string> = {};
        if (config?.kaleidoRestUrl) headers['x-kaleido-url'] = config.kaleidoRestUrl;
        if (config?.kaleidoAuthHeader) headers['x-kaleido-auth'] = config.kaleidoAuthHeader;

        const response = await fetch("/api/kaleido", { headers });
        if (response.ok) {
          const result = await response.json();
          setData(result);
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, [user, config]);

  if (!user) {
    return <LoginScreen data={data} config={config} />;
  }

  if (showSubscriptions) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-foreground flex flex-col">
        <div className="flex justify-end p-4">
          <Button variant="ghost" onClick={() => signOut(auth)} className="text-white/50 hover:text-white">
            <LogOut className="mr-2 h-4 w-4" /> Sign Out
          </Button>
        </div>
        <SubscriptionPlans onSelectPlan={(plan) => {
          setSubscriptionTier(plan);
          setShowSubscriptions(false);
          // In a real app, save this to Firestore after payment
        }} />
      </div>
    );
  }

  const appName = config?.appName || "Axiom Trading Platform";
  const primaryColor = config?.primaryColor || "#3b82f6";
  const logoUrl = config?.logoUrl || "";

  return (
    <div className="flex h-screen w-full overflow-hidden bg-transparent text-foreground" style={{ '--primary-color': primaryColor } as React.CSSProperties}>
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 border-r border-white/10 glass-panel flex flex-col z-10">
        <div className="p-6 flex items-center gap-3 border-b border-white/10">
          {logoUrl ? (
            <img src={logoUrl} alt={appName} className="h-8 w-8 rounded-full object-cover shadow-[0_0_15px_var(--primary-color)]" />
          ) : (
            <div 
              className="h-8 w-8 rounded-full flex items-center justify-center shadow-[0_0_15px_var(--primary-color)]"
              style={{ backgroundColor: primaryColor }}
            >
              <Zap className="h-4 w-4 text-white" />
            </div>
          )}
          <h1 className="font-bold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60 truncate">
            {appName}
          </h1>
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <div className="px-4 py-2 text-[10px] font-bold text-white/40 uppercase tracking-widest">Core</div>
          <NavItem icon={<LayoutDashboard size={18} />} label="Overview" active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
          <NavItem icon={<Box size={18} />} label="Nodes" active={activeTab === 'nodes'} onClick={() => setActiveTab('nodes')} />
          <NavItem icon={<Activity size={18} />} label="Stability Monitor" active={activeTab === 'stability'} onClick={() => setActiveTab('stability')} />

          <div className="px-4 py-2 mt-4 text-[10px] font-bold text-white/40 uppercase tracking-widest">Assets & Issuance</div>
          <NavItem icon={<Coins size={18} />} label="Asset Issuance" active={activeTab === 'issuance'} onClick={() => setActiveTab('issuance')} />
          <NavItem icon={<Building2 size={18} />} label="RWA Infrastructure" active={activeTab === 'rwa'} onClick={() => setActiveTab('rwa')} />
          <NavItem icon={<ImageIcon size={18} />} label="NFT Marketplace" active={activeTab === 'nft'} onClick={() => setActiveTab('nft')} />

          <div className="px-4 py-2 mt-4 text-[10px] font-bold text-white/40 uppercase tracking-widest">Markets & Trading</div>
          <NavItem icon={<LineChartIcon size={18} />} label="Spot & Sports Trading" active={activeTab === 'spot'} onClick={() => setActiveTab('spot')} />
          <NavItem icon={<TrendingUp size={18} />} label="Derivatives" active={activeTab === 'derivatives'} onClick={() => setActiveTab('derivatives')} />
          <NavItem icon={<Users size={18} />} label="Copy Trading" active={activeTab === 'copytrading'} onClick={() => setActiveTab('copytrading')} />
          <NavItem icon={<Rocket size={18} />} label="Launchpad" active={activeTab === 'launchpad'} onClick={() => setActiveTab('launchpad')} />

          <div className="px-4 py-2 mt-4 text-[10px] font-bold text-white/40 uppercase tracking-widest">Infrastructure</div>
          <NavItem icon={<Pickaxe size={18} />} label="Mining Pools" active={activeTab === 'mining'} onClick={() => setActiveTab('mining')} />
          <NavItem icon={<Shield size={18} />} label="Custody & Storage" active={activeTab === 'custody'} onClick={() => setActiveTab('custody')} />

          <div className="px-4 py-2 mt-4 text-[10px] font-bold text-white/40 uppercase tracking-widest">System</div>
          <NavItem icon={<Settings size={18} />} label="Settings" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </nav>
        <div className="p-4 border-t border-white/10 text-xs text-white/40 text-center">
          {user.email}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative z-0">
        {/* Header */}
        <header className="h-20 flex-shrink-0 border-b border-white/10 glass-panel flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-3">
            <div className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]"></span>
            </div>
            <span className="text-sm font-medium text-white/80 tracking-wide uppercase">Network Health: Optimal</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-white/60 hover:text-white hover:bg-white/10" onClick={() => signOut(auth)}>
              Sign Out
            </Button>
            <Button 
              className="glass-panel text-white transition-all duration-300"
              style={{ borderColor: primaryColor, boxShadow: `0 0 10px ${primaryColor}40` }}
            >
              <Wallet className="mr-2 h-4 w-4" /> Connect Wallet
            </Button>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {activeTab === 'settings' && <SettingsPanel config={config} onConfigSaved={(newConfig) => setConfig(newConfig)} />}
          {activeTab === 'issuance' && <AssetIssuance primaryColor={primaryColor} userUid={user.uid} config={config} />}
          {activeTab === 'rwa' && <RWAInfrastructure primaryColor={primaryColor} userUid={user.uid} config={config} />}
          {activeTab === 'nft' && <NFTMarketplace primaryColor={primaryColor} userUid={user.uid} config={config} />}
          {activeTab === 'spot' && <TradingEngine primaryColor={primaryColor} />}
          {activeTab === 'derivatives' && <Derivatives primaryColor={primaryColor} userUid={user.uid} />}
          {activeTab === 'copytrading' && <CopyTrading primaryColor={primaryColor} userUid={user.uid} />}
          {activeTab === 'launchpad' && <Launchpad primaryColor={primaryColor} userUid={user.uid} />}
          {activeTab === 'mining' && <MiningPools primaryColor={primaryColor} userUid={user.uid} />}
          {activeTab === 'custody' && <CustodyStorage primaryColor={primaryColor} userUid={user.uid} />}

          {(activeTab === 'overview' || activeTab === 'nodes' || activeTab === 'stability') && (
            <>
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                  title="Node State (Φ)" 
                  value={data?.nodeState} 
                  loading={loading} 
                  borderColor={primaryColor}
                />
                <StatCard 
                  title="Chaos Level (Γ)" 
                  value={data?.chaosLevel} 
                  loading={loading} 
                  borderClass="neon-border-red"
                />
                <StatCard 
                  title="Damping (Λ)" 
                  value={data?.damping} 
                  loading={loading} 
                  borderClass="neon-border-purple"
                />
                <StatCard 
                  title="Sync Status" 
                  value={data?.syncStatus} 
                  loading={loading} 
                  borderClass="neon-border-gold"
                  valueClass={data?.syncStatus === "Synced" ? "text-green-400" : "text-yellow-400"}
                />
              </div>

              {/* Chart Section */}
              <Card className="glass-panel neon-border-purple glow-hover border-t-2">
                <CardHeader>
                  <CardTitle className="text-lg font-medium text-white/90 flex items-center gap-2">
                    <Activity className="h-5 w-5 text-[#c300ff]" />
                    Real-time Stability Chart
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] w-full mt-4">
                    {loading ? (
                      <Skeleton className="h-full w-full bg-white/5 rounded-lg" />
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data?.chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                          <XAxis 
                            dataKey="time" 
                            stroke="rgba(255,255,255,0.3)" 
                            tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }}
                            tickLine={false}
                            axisLine={false}
                          />
                          <YAxis 
                            stroke="rgba(255,255,255,0.3)" 
                            tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }}
                            tickLine={false}
                            axisLine={false}
                          />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: 'rgba(0,0,0,0.8)', 
                              borderColor: 'rgba(195,0,255,0.5)',
                              borderRadius: '8px',
                              boxShadow: '0 0 15px rgba(195,0,255,0.3)'
                            }} 
                            itemStyle={{ color: '#fff' }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="stability" 
                            stroke="#c300ff" 
                            strokeWidth={3}
                            dot={false}
                            activeDot={{ r: 6, fill: "#c300ff", stroke: "#fff", strokeWidth: 2 }}
                            style={{ filter: 'drop-shadow(0 0 8px rgba(195,0,255,0.8))' }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="chaos" 
                            stroke="#ff2600" 
                            strokeWidth={2}
                            strokeDasharray="5 5"
                            dot={false}
                            style={{ filter: 'drop-shadow(0 0 5px rgba(255,38,0,0.5))' }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Table Section */}
              <Card className="glass-panel glow-hover border-t-2" style={{ borderColor: primaryColor }}>
                <CardHeader>
                  <CardTitle className="text-lg font-medium text-white/90 flex items-center gap-2">
                    <Box className="h-5 w-5" style={{ color: primaryColor }} />
                    Recent Blocks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="space-y-3 mt-4">
                      <Skeleton className="h-10 w-full bg-white/5" />
                      <Skeleton className="h-10 w-full bg-white/5" />
                      <Skeleton className="h-10 w-full bg-white/5" />
                      <Skeleton className="h-10 w-full bg-white/5" />
                    </div>
                  ) : (
                    <div className="rounded-md border border-white/10 overflow-hidden mt-4">
                      <Table>
                        <TableHeader className="bg-white/5">
                          <TableRow className="border-white/10 hover:bg-transparent">
                            <TableHead className="text-white/60">Block ID</TableHead>
                            <TableHead className="text-white/60">Timestamp</TableHead>
                            <TableHead className="text-white/60 text-right">Transactions</TableHead>
                            <TableHead className="text-white/60 text-right">Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {data?.recentBlocks.map((block) => (
                            <TableRow key={block.id} className="border-white/10 hover:bg-white/5 transition-colors">
                              <TableCell className="font-mono text-white/80">{block.id}</TableCell>
                              <TableCell className="text-white/60">
                                {new Date(block.timestamp).toLocaleTimeString()}
                              </TableCell>
                              <TableCell className="text-right text-white/80">{block.transactions}</TableCell>
                              <TableCell className="text-right">
                                <Badge 
                                  variant="outline" 
                                  className={`
                                    ${block.status === 'Confirmed' 
                                      ? 'border-green-500/50 text-green-400 bg-green-500/10 shadow-[0_0_10px_rgba(34,197,94,0.2)]' 
                                      : 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10 shadow-[0_0_10px_rgba(234,179,8,0.2)]'}
                                  `}
                                >
                                  {block.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}

function LoginScreen({ data, config }: { data: any, config: any }) {
  const [loginMethod, setLoginMethod] = useState<'form' | 'qr'>('form');
  const appName = config?.appName || 'Axiom Trading Platform';
  const primaryColor = config?.primaryColor || '#3b82f6';

  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleAppleLogin = async () => {
    try {
      const provider = new OAuthProvider('apple.com');
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Apple Login failed", error);
      // Fallback to Google for demo purposes if Apple isn't configured in Firebase
      handleGoogleLogin();
    }
  };

  return (
    <div className="flex min-h-screen w-full bg-transparent text-foreground">
      {/* Left Branding Panel (Hidden on mobile) */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 relative overflow-hidden">
        {/* Background decorative chart */}
        <div className="absolute inset-0 opacity-20 pointer-events-none z-0">
          {data?.chartData && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.chartData}>
                <Line type="monotone" dataKey="stability" stroke={primaryColor} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="chaos" stroke="#ff2600" strokeWidth={1} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-8">
            {config?.logoUrl ? (
              <img src={config.logoUrl} alt={appName} className="h-10 w-10 rounded-full object-cover shadow-[0_0_20px_rgba(255,255,255,0.2)]" />
            ) : (
              <div className="h-10 w-10 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.2)]" style={{ backgroundColor: primaryColor }}>
                <Zap className="h-5 w-5 text-white" />
              </div>
            )}
            <h1 className="font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
              {appName}
            </h1>
          </div>
          <h2 className="text-5xl font-bold tracking-tighter text-white mb-6 leading-tight">
            Institutional Trading <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/50" style={{ backgroundImage: `linear-gradient(to right, ${primaryColor}, #ffffff)` }}>
              Made Simple
            </span>
          </h2>
          <p className="text-white/60 text-lg max-w-md">
            Trade derivatives, join launchpads, and manage assets in under 60 seconds. Powered by MPC Custody.
          </p>
        </div>

        <div className="relative z-10 glass-panel p-6 rounded-xl max-w-md" style={{ borderColor: `${primaryColor}40` }}>
          <div className="flex items-center gap-4 mb-4">
            <ShieldCheck className="h-8 w-8" style={{ color: primaryColor }} />
            <div>
              <h3 className="text-white font-medium">MPC Custody Powered by Kaleido KMS</h3>
              <p className="text-white/50 text-sm">No seed phrases required. Institutional Security.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Login Panel */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 relative z-10">
        <Card className="w-full max-w-md glass-panel border-t-2 relative overflow-hidden" style={{ borderTopColor: primaryColor }}>
          <CardHeader className="pt-10 pb-6 text-center">
            <CardTitle className="text-2xl font-bold text-white">
              Welcome to {appName}
            </CardTitle>
            <CardDescription className="text-white/50">
              Sign in to access your secure MPC wallet
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            <Button 
              onClick={handleAppleLogin}
              className="w-full bg-white text-black hover:bg-white/90 h-12 text-lg font-medium flex items-center justify-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" className="h-5 w-5"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/></svg>
              Continue with Apple / FaceID
            </Button>
            
            <Button 
              onClick={handleGoogleLogin}
              className="w-full bg-white/10 text-white hover:bg-white/20 border border-white/10 h-12 text-lg font-medium flex items-center justify-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512" className="h-5 w-5 fill-current"><path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"/></svg>
              Continue with Google
            </Button>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-white/10" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-[#0a0a0a] px-2 text-white/40">Secure & Instant</span>
              </div>
            </div>

            <p className="text-center text-xs text-white/40 mt-4">
              By continuing, you agree to our Terms of Service and Privacy Policy. Your wallet is securely generated via Multi-Party Computation (MPC).
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active = false, onClick }: { icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`
        w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300
        ${active 
          ? 'bg-white/10 text-white shadow-[inset_2px_0_0_var(--primary-color)]' 
          : 'text-white/60 hover:bg-white/5 hover:text-white'}
      `}
    >
      <span className={active ? 'drop-shadow-[0_0_8px_var(--primary-color)]' : ''} style={active ? { color: 'var(--primary-color)' } : {}}>
        {icon}
      </span>
      <span className="font-medium text-sm">{label}</span>
    </button>
  );
}

function StatCard({ 
  title, 
  value, 
  loading, 
  borderClass,
  borderColor,
  valueClass = "text-white"
}: { 
  title: string; 
  value?: string; 
  loading: boolean;
  borderClass?: string;
  borderColor?: string;
  valueClass?: string;
}) {
  return (
    <Card 
      className={`glass-panel ${borderClass || ''} glow-hover border-t-2 overflow-hidden relative group`}
      style={borderColor ? { borderColor: borderColor } : {}}
    >
      {/* Subtle background gradient that appears on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <CardHeader className="pb-2 relative z-10">
        <CardTitle className="text-sm font-medium text-white/60 uppercase tracking-wider">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="relative z-10">
        {loading ? (
          <Skeleton className="h-10 w-24 bg-white/10 rounded" />
        ) : (
          <div className={`text-3xl font-bold font-mono tracking-tight ${valueClass}`}>
            {value}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

